import React from 'react'
import Projectmanagement from './projectmanagement'

function page() {
  return (
    <><Projectmanagement /></>
  )
}

export default page